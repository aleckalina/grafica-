package com.example.svetovor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView textview;
    Button buttonRed;
    Button buttonYellow;
    Button buttonGreen;
    ConstraintLayout mcant;
    private ConstraintLayout mConstraintLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textview = (TextView) findViewById(R.id.textView);
        buttonRed=(Button)findViewById(R.id.buttonRed);
        buttonYellow=(Button)findViewById(R.id.buttonYellow);
        buttonGreen=(Button)findViewById(R.id.buttonGreen);
        mConstraintLayout = (ConstraintLayout) findViewById(R.id.mcant);
        View.OnClickListener textColorR=new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textview.setText("Красный");
                mConstraintLayout.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.redColor));
            }
        };
        buttonRed.setOnClickListener(textColorR);
        View.OnClickListener textColorY = new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                textview.setText("Желтый");
                mConstraintLayout.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.yellowColor));
            }
        };
        buttonYellow.setOnClickListener(textColorY);
        View.OnClickListener textColorG = new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                textview.setText("Зеленый");
                mConstraintLayout.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.greenColor));
            }
        };
        buttonGreen.setOnClickListener(textColorG);
    }
}